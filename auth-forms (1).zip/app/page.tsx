import Component from "../auth-forms"

export default function Page() {
  return <Component />
}
